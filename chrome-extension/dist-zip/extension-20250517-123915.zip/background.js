var R = { exports: {} }, q = R.exports, U;
function G() {
  return U || (U = 1, function(t, h) {
    (function(a, o) {
      o(t);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : q, function(a) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        a.exports = globalThis.browser;
      else {
        const o = "The message port closed before a response was received.", w = (u) => {
          const f = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(f).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class L extends WeakMap {
            constructor(r, n = void 0) {
              super(n), this.createItem = r;
            }
            get(r) {
              return this.has(r) || this.set(r, this.createItem(r)), super.get(r);
            }
          }
          const _ = (e) => e && typeof e == "object" && typeof e.then == "function", y = (e, r) => (...n) => {
            u.runtime.lastError ? e.reject(new Error(u.runtime.lastError.message)) : r.singleCallbackArg || n.length <= 1 && r.singleCallbackArg !== !1 ? e.resolve(n[0]) : e.resolve(n);
          }, p = (e) => e == 1 ? "argument" : "arguments", F = (e, r) => function(g, ...A) {
            if (A.length < r.minArgs)
              throw new Error(`Expected at least ${r.minArgs} ${p(r.minArgs)} for ${e}(), got ${A.length}`);
            if (A.length > r.maxArgs)
              throw new Error(`Expected at most ${r.maxArgs} ${p(r.maxArgs)} for ${e}(), got ${A.length}`);
            return new Promise((c, x) => {
              if (r.fallbackToNoCallback)
                try {
                  g[e](...A, y({
                    resolve: c,
                    reject: x
                  }, r));
                } catch (s) {
                  console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, s), g[e](...A), r.fallbackToNoCallback = !1, r.noCallback = !0, c();
                }
              else r.noCallback ? (g[e](...A), c()) : g[e](...A, y({
                resolve: c,
                reject: x
              }, r));
            });
          }, M = (e, r, n) => new Proxy(r, {
            apply(g, A, c) {
              return n.call(A, e, ...c);
            }
          });
          let k = Function.call.bind(Object.prototype.hasOwnProperty);
          const T = (e, r = {}, n = {}) => {
            let g = /* @__PURE__ */ Object.create(null), A = {
              has(x, s) {
                return s in e || s in g;
              },
              get(x, s, d) {
                if (s in g)
                  return g[s];
                if (!(s in e))
                  return;
                let m = e[s];
                if (typeof m == "function")
                  if (typeof r[s] == "function")
                    m = M(e, e[s], r[s]);
                  else if (k(n, s)) {
                    let v = F(s, n[s]);
                    m = M(e, e[s], v);
                  } else
                    m = m.bind(e);
                else if (typeof m == "object" && m !== null && (k(r, s) || k(n, s)))
                  m = T(m, r[s], n[s]);
                else if (k(n, "*"))
                  m = T(m, r[s], n["*"]);
                else
                  return Object.defineProperty(g, s, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return e[s];
                    },
                    set(v) {
                      e[s] = v;
                    }
                  }), m;
                return g[s] = m, m;
              },
              set(x, s, d, m) {
                return s in g ? g[s] = d : e[s] = d, !0;
              },
              defineProperty(x, s, d) {
                return Reflect.defineProperty(g, s, d);
              },
              deleteProperty(x, s) {
                return Reflect.deleteProperty(g, s);
              }
            }, c = Object.create(e);
            return new Proxy(c, A);
          }, C = (e) => ({
            addListener(r, n, ...g) {
              r.addListener(e.get(n), ...g);
            },
            hasListener(r, n) {
              return r.hasListener(e.get(n));
            },
            removeListener(r, n) {
              r.removeListener(e.get(n));
            }
          }), N = new L((e) => typeof e != "function" ? e : function(n) {
            const g = T(n, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            e(g);
          }), i = new L((e) => typeof e != "function" ? e : function(n, g, A) {
            let c = !1, x, s = new Promise((S) => {
              x = function(b) {
                c = !0, S(b);
              };
            }), d;
            try {
              d = e(n, g, x);
            } catch (S) {
              d = Promise.reject(S);
            }
            const m = d !== !0 && _(d);
            if (d !== !0 && !m && !c)
              return !1;
            const v = (S) => {
              S.then((b) => {
                A(b);
              }, (b) => {
                let B;
                b && (b instanceof Error || typeof b.message == "string") ? B = b.message : B = "An unexpected error occurred", A({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: B
                });
              }).catch((b) => {
                console.error("Failed to send onMessage rejected reply", b);
              });
            };
            return v(m ? d : s), !0;
          }), E = ({
            reject: e,
            resolve: r
          }, n) => {
            u.runtime.lastError ? u.runtime.lastError.message === o ? r() : e(new Error(u.runtime.lastError.message)) : n && n.__mozWebExtensionPolyfillReject__ ? e(new Error(n.message)) : r(n);
          }, I = (e, r, n, ...g) => {
            if (g.length < r.minArgs)
              throw new Error(`Expected at least ${r.minArgs} ${p(r.minArgs)} for ${e}(), got ${g.length}`);
            if (g.length > r.maxArgs)
              throw new Error(`Expected at most ${r.maxArgs} ${p(r.maxArgs)} for ${e}(), got ${g.length}`);
            return new Promise((A, c) => {
              const x = E.bind(null, {
                resolve: A,
                reject: c
              });
              g.push(x), n.sendMessage(...g);
            });
          }, W = {
            devtools: {
              network: {
                onRequestFinished: C(N)
              }
            },
            runtime: {
              onMessage: C(i),
              onMessageExternal: C(i),
              sendMessage: I.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: I.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, j = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return f.privacy = {
            network: {
              "*": j
            },
            services: {
              "*": j
            },
            websites: {
              "*": j
            }
          }, T(u, W, f);
        };
        a.exports = w(chrome);
      }
    });
  }(R)), R.exports;
}
G();
var P;
(function(t) {
  t.Local = "local", t.Sync = "sync", t.Managed = "managed", t.Session = "session";
})(P || (P = {}));
var O;
(function(t) {
  t.ExtensionPagesOnly = "TRUSTED_CONTEXTS", t.ExtensionPagesAndContentScripts = "TRUSTED_AND_UNTRUSTED_CONTEXTS";
})(O || (O = {}));
const l = globalThis.chrome, $ = async (t, h) => {
  const a = (w) => typeof w == "function", o = (w) => w instanceof Promise;
  return a(t) ? (o(t), t(h)) : t;
};
let D = !1;
function z(t) {
  if (l && l.storage[t] === void 0)
    throw new Error(`Check your storage permission in manifest.json: ${t} is not defined`);
}
function Z(t, h, a) {
  var C, N;
  let o = null, w = !1, u = [];
  const f = (a == null ? void 0 : a.storageEnum) ?? P.Local, L = ((C = a == null ? void 0 : a.serialization) == null ? void 0 : C.serialize) ?? ((i) => i), _ = ((N = a == null ? void 0 : a.serialization) == null ? void 0 : N.deserialize) ?? ((i) => i);
  D === !1 && f === P.Session && (a == null ? void 0 : a.sessionAccessForContentScripts) === !0 && (z(f), l == null || l.storage[f].setAccessLevel({
    accessLevel: O.ExtensionPagesAndContentScripts
  }).catch((i) => {
    console.warn(i), console.warn("Please call setAccessLevel into different context, like a background script.");
  }), D = !0);
  const y = async () => {
    z(f);
    const i = await (l == null ? void 0 : l.storage[f].get([t]));
    return i ? _(i[t]) ?? h : h;
  }, p = () => {
    u.forEach((i) => i());
  }, F = async (i) => {
    w || (o = await y()), o = await $(i, o), await (l == null ? void 0 : l.storage[f].set({ [t]: L(o) })), p();
  }, M = (i) => (u = [...u, i], () => {
    u = u.filter((E) => E !== i);
  }), k = () => o;
  y().then((i) => {
    o = i, w = !0, p();
  });
  async function T(i) {
    if (i[t] === void 0)
      return;
    const E = _(i[t].newValue);
    o !== E && (o = await $(E, o), p());
  }
  return l == null || l.storage[f].onChanged.addListener(T), {
    get: y,
    set: F,
    getSnapshot: k,
    subscribe: M
  };
}
const K = Z("options-storage-key", {
  backendUrl: "https://api.jidhr.com/vocabulary",
  apiToken: ""
}, {
  storageEnum: P.Local
});
console.log("Background loaded");
console.log("Edit 'chrome-extension/src/background/index.ts' and save to reload.");
const V = [
  "https://api.jidhr.com",
  "https://www.jidhr.com",
  "https://jidhr.com",
  "http://localhost:3000"
];
chrome.runtime.onMessageExternal.addListener(async (t, h, a) => {
  if (!h.origin || !V.includes(h.origin)) {
    console.error(`Unauthorized message from ${h.origin || "unknown origin"}`), a({ success: !1, error: "Unauthorized origin" });
    return;
  }
  if (t.type === "PING") {
    a({ success: !0 });
    return;
  }
  if (t.type === "SET_API_KEY")
    try {
      await K.set((o) => ({
        ...o,
        apiToken: t.apiKey
      })), chrome.notifications.create({
        type: "basic",
        iconUrl: chrome.runtime.getURL("jidhr_logo_transparant_34.png"),
        title: "Jidhr.com successfully connected",
        message: "Your API key has been set successfully. You can now use the extension."
      }), a({ success: !0 });
    } catch (o) {
      console.error("Error setting API key:", o), a({ success: !1, error: "Failed to set API key" });
    }
});
